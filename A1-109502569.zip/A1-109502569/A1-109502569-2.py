"""
Assignment 1
Name: 陳彥呈
Student Number:109502569
Course 2020-CE1003-B
"""
a,b = int(input()),int(input())
print(a+b,a-b,a*b,float(a/b),a**b,a//b,a%b,sep='\n')