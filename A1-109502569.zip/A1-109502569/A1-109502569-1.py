"""
Assignment 1
Name: 陳彥呈
Student Number:109502569
Course 2020-CE1003-B
"""
str1 = input("input1:")
str2 = input("input2:")
str3 = input("input3:")
print(str3,str2,str1)