"""
Assignment 1
Name: 陳彥呈
Student Number:109502569
Course 2020-CE1003-B
"""
string = input()
print("hello world",string)